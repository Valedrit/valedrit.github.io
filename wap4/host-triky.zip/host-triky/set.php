<?php
/////////
$auto = 'http://link auto login xtgem';
/////////
$tenwap = explode('/',$auto);
$server = $tenwap[2];
$tenwap = base64_decode($tenwap[5]);
$ua = 'Opera/9.80 (J2ME/MIDP; Opera Mini/9.80 (S60; SymbOS; Opera Mobi/23.348; U; en) Presto/2.5.25 Version/10.54';
$cookies = 'cooki.txt';
$wap4 = 'http://tên wap4 của bạn';
?>