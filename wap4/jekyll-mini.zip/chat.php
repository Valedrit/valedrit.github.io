{% import 'func.twig' as func %}
{% from 'func.twig' import get %}

{% set login = func.login|trim %}
{% set name = login %}
{% set msg = get_post('msg') %}
{% set now = "now"|date("U") %}
{# {% if request_method()|lower=='POST' %} #}
{% if msg != '' and msg != '\r\n' and msg!=null %}
{% set comment = {"name" :name,"time":now,"comment":msg} %}
{% set status = save_data( "chat", comment|json_encode ) %}

{% endif %}
{# {% endif %} #}
{% set data=[] %}
{% set play='yes' %}
{% for i in 1..100 %}
{% if play=='yes' %}
{% set data2=get_data( 'chat',100,i) %}
{% endif %}
{% if data2 %}
{% set data=data2|reverse|merge(data) %}
{% else %}
{% set play='no' %}
{% set data2='' %}
{% endif %}
{% endfor %}
{% set total=data|length %}
{% set per = '5' %}
 {% set page_max=total//per %}
{% if total//per != total/per %}
{% set page_max=total//per+1 %}
{% endif %}
 {% set url=get_get('page') %}
{% set p=url|default('1') %}
{% if p matches '/[a-zA-z]|%/' or p<1 %}
{% set p=1 %}
{% endif %}
{% if p>page_max %}
{% set p=page_max %}
{% endif %}
{% set st=p*per-per %}
{% from 'sync.twig' import ago,bbcode %}
{% set entries= data|slice(st,5) %}
{% set data='' %}
{% if total == 0 %}
<div class="rmenu">Chưa có nội dung nào</div>
{% endif %}
{% for tiax in entries %}
{% set entry = tiax.data|json_decode %}
{% set user='user_'~entry.name %}
{% set nd = entry.comment %}
{% set on=func.get(user,'on')|trim %}
{% set time = entry.time %}
{% set jun = now-time %}
{% if jun > 1 %}
{% set pre = 'menu' %}
{% set agos = ago(time) %}
{% else %}
{% set pre = 'nchat' %}
{% set agos = 'vừa xong' %}
{% endif %}
 <div class="list1">{% if entry.name %}<span name="online">{% if on < ('now'|date('U')-300) %}<font color="red">•</font>{% else %}<font color="green">•</font>{% endif %}</span><img src="https://images.weserv.nl/?url=https://jekyll.gq/images/{{get(user,'avt')}}.png&w=25&h=25&t=square&mask=circle" width="20px" /> <a href="/user/{{entry.name}}">
{{func.get(user,'nick')}}
</a>{% endif %}: {{bbcode(nd|raw)}} <font color="#999">{{agos}}</font>
</div>
{% endfor %}
{% if login and login not in func.get('show_online')|split('@') %}
{{func.up('show_online',login,'up')}}
{% endif %}